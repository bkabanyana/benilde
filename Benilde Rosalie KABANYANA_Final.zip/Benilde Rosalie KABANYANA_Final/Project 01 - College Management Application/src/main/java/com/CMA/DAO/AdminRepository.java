package com.CMA.DAO;

import org.springframework.data.repository.CrudRepository;

import com.CMA.entities.AdminEntity;

public interface AdminRepository extends CrudRepository<AdminEntity, Long> {

}
