package com.CMA.DAO;

import org.springframework.data.repository.CrudRepository;

import com.CMA.entities.CourseEntity;

public interface CourseRepository extends CrudRepository<CourseEntity, Long> {

}
