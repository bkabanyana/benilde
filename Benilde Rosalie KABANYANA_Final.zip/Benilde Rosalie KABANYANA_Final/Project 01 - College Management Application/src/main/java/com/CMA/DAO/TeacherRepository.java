package com.CMA.DAO;

import org.springframework.data.repository.CrudRepository;

import com.CMA.entities.TeacherEntity;

public interface TeacherRepository extends CrudRepository<TeacherEntity, Long>{

}
