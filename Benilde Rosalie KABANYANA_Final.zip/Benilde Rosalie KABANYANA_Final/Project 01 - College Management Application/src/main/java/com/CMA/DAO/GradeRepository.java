package com.CMA.DAO;

import org.springframework.data.repository.CrudRepository;

import com.CMA.entities.GradeEntity;

public interface GradeRepository extends CrudRepository<GradeEntity, Long> {

}
